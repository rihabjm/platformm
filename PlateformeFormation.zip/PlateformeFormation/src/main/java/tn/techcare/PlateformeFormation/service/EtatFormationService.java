package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.EtatFormation;

public interface EtatFormationService {

	public List<EtatFormation>getAllEtat();
	public String getEtatById(int id);
	
}
