package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationMetiersService {
	public MessageReponse ajoutFormation(FormationMetiers formation) ;
	public List<FormationMetiers>getAllFormation();
}
