package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.FormationModule;



public interface FormationModuleRepository extends JpaRepository<FormationModule, Integer> {

}
