package tn.techcare.PlateformeFormation.service;


import java.util.List;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationModuleService {
	public MessageReponse ajoutFormationModule (FormationModule formation) ;
	public List<FormationModule>getAllFormation();
	
}
