package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormationMetiersRepository;
import tn.techcare.PlateformeFormation.service.FormationMetiersService;

@Service
@Transactional
public class FormationMetiersImpService implements FormationMetiersService {
	@Autowired
	private FormationMetiersRepository formationmetiersRepository ;
    
	
	@Transactional
	@Override
	public MessageReponse ajoutFormation(FormationMetiers formation) {
		
	
		formationmetiersRepository.save(formation);
		return  new MessageReponse(true, formation.getId_formation()+ "formation est ajouter ") ;
	}

	@Override
	public List<FormationMetiers> getAllFormation() {
		
		
	return formationmetiersRepository.findAll();
	}


	
	


	
}
