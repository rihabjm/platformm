package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationService  {

	public MessageReponse ajoutFormation (Formation formation) ;
  public List<Formation> getAllFormation();
}
