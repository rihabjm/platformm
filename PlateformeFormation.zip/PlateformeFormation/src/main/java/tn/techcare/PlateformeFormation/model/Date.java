package tn.techcare.PlateformeFormation.model;


import java.time.LocalDate;
import java.util.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "date")
public class Date {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_date;
    @JsonFormat(pattern="yyyy-MM-dd")
  private LocalDate datedb ;
    @JsonFormat(pattern="yyyy-MM-dd")
  private LocalDate datefin ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "date", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "date", cascade = {
	        CascadeType.ALL
	    })
	private List<Promotion> promotion ;
	
	public int getId_date() {
		return id_date;
	}
	public void setId_date(int id_date) {
		this.id_date = id_date;
	}
	
	public LocalDate getDatedb() {
		return datedb;
	}
	public void setDatedb(LocalDate datedb) {
		this.datedb = datedb;
	}
	public LocalDate getDatefin() {
		return datefin;
	}
	public void setDatefin(LocalDate datefin) {
		this.datefin = datefin;
	}
	public List<Formation> getFormations() {
		return formations;
	}
	public void setFormations(List<Formation> formations) {
		this.formations = formations;
	}
	public List<Promotion> getPromotion() {
		return promotion;
	}
	public void setPromotion(List<Promotion> promotion) {
		this.promotion = promotion;
	}

	
	
}
